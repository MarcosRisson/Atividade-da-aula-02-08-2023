package aula;

public class Aluno {

    private int ra;
    private String nome , situacao ;
    private double prova1;
    private double prova2;
    private double trabalho;

    private  double mediaFinal;


    public Aluno(int ra, String nome, double prova1, double prova2, double trabalho) {
        this.ra = ra;
        this.nome = nome;
        this.prova1 = prova1;
        this.prova2 = prova2;
        this.trabalho = trabalho;
    }

    public void Media(){
    mediaFinal = (prova1 * 0.35 ) + (prova2 * 0.35) + (trabalho * 0.3);
    String mediaConvertida = String.format("%.2f", mediaFinal);
        System.out.println("Sua media final é: " + mediaConvertida);
    }

    public void Situacao(){
        if (mediaFinal>=7 ){
            situacao = "APROVADO";
        }else{
            situacao = "EXAME";
        }
        System.out.println("A sua Situaçao é: " + situacao);
    }

    public String toString(){
        System.out.println("Ra : "+ ra + " / " + "Nome: " + nome);
        return null;
    }
}





