package aula;

import javax.print.attribute.standard.Media;
import java.util.Scanner;



public class Main {


    public static void main(String[] args) {
        int ra;
        double prova1;
        double prova2;
        double trabalho;
        String nome;
        boolean vali = true;
        Scanner scanner = new Scanner(System.in);
        while (vali) {
                try {
                  do {

                System.out.print("Digite seu Registro Academico:");
                ra = scanner.nextInt();
                scanner = new Scanner(System.in);
                }while (ra <0);

                System.out.print("Digite seu Nome:");
                nome = scanner.nextLine();
                scanner = new Scanner(System.in);

                do {
                        System.out.print("Digite a nota da Prova1 de 0 a 10: ");
                        prova1 = scanner.nextDouble();
                        scanner = new Scanner(System.in);
                        if (prova1 < 0 || prova1 > 10 ){
                                System.out.println("Valor invalido");
                        }
                }while (prova1 < 0 || prova1 > 10 );

                do {


                System.out.print("Digite a nota da Prova 2:");
                        prova2 = scanner.nextDouble();
                        scanner = new Scanner(System.in);
                        if (prova2 < 0 || prova1 > 10 ){
                                System.out.println("Valor invalido");
                        }
                }while (prova2 < 0 || prova1 > 10 );

                    do {
                        System.out.print("Digite  a nota do seu Trabalho de 0 a 10: ");
                        trabalho = scanner.nextDouble();
                        scanner = new Scanner(System.in);
                        if (trabalho < 0 || trabalho > 10) {
                            System.out.println("Valor invalido!");
                        }
                    } while (trabalho < 0 || trabalho > 10);

                    Aluno aluno = new Aluno(ra,nome,prova1 , prova2 , trabalho);

                    System.out.println("RESULTADO");
                    aluno.toString();
                    aluno.Media();
                    aluno.Situacao();

                }catch (Exception e){
                        System.out.println("Erro!!!");
                        scanner = new Scanner(System.in);
                }
        }
    }
}